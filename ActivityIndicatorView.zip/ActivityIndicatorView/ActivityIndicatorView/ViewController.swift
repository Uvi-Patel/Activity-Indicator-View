//
//  ViewController.swift
//  ActivityIndicatorView
//
//  Created by MAC on 25/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let Indicator = UIActivityIndicatorView()
        Indicator.startAnimating()
        Indicator.frame = CGRect.init(x: 50, y: 200, width: 100, height: 100)
        let transform: CGAffineTransform = CGAffineTransform(scaleX: 1.5, y: 1.5)
        Indicator.transform = transform
        Indicator.style = .large
        Indicator.color = .red
        Indicator.layer.cornerRadius = 15
        Indicator.backgroundColor = UIColor.cyan
//        Indicator.stopAnimating()
        self.perform(#selector(self.stoploading), with: Indicator, afterDelay: 5)
        Indicator.hidesWhenStopped = false
        view.addSubview(Indicator)
        // Do any additional setup after loading the view.
    }

    @objc func stoploading(activity:UIActivityIndicatorView){
        activity.stopAnimating()
    }
    
}

